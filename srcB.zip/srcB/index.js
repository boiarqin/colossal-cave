/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
//COLOSSAL CAVE ADVENTURE IMPLEMENTATION FOR ALEXA
'use strict';

const Alexa = require('alexa-sdk');

//constiables
const output = '';


const HELP_MESSAGE = 'I KNOW';

const WELCOME_MESSAGE = 'YOU';

const handlers = {
	'LaunchRequest' : function(){
		this.emit(':ask', WELCOME_MESSAGE, HELP_MESSAGE);
	}
};

//export handler
exports.handler = function(event, context, callback){
	const alexa = Alexa.handler(event, context);
	alexa.registerHandlers(handlers); //TODO
	alexa.execute();
};